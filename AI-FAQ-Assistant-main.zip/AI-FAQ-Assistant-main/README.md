# 🤖 AI FAQ Assistant

An AI-powered FAQ chatbot that answers user questions using a predefined FAQ knowledge base.

## 📌 Project Overview

The AI FAQ Assistant allows users to ask questions in natural language and receive relevant answers from the available FAQ information.

The project uses a local AI model, so it does not require a paid AI API.

## 🛠️ Technologies Used

- HTML
- CSS
- JavaScript
- Python
- Flask
- Ollama
- Llama 3.2 (3B)
- JSON
- Git & GitHub

## ⚙️ How It Works

1. The user enters a question in the chatbot.
2. JavaScript sends the question to the Flask backend.
3. Flask loads the FAQ information from `faqs.json`.
4. The FAQ information and user question are sent to the local Ollama AI model.
5. The AI understands the question and generates an answer.
6. The answer is displayed in the chatbot.

## 📂 Project Structure

```text
AI-FAQ-Assistant/
│
├── app.py
├── faqs.json
├── requirements.txt
├── README.md
├── .gitignore
│
├── templates/
│   └── index.html
│
├── app_backup.py
│
└── venv/