from flask import Flask, render_template, request, jsonify
import json
import ollama

app = Flask(__name__)


# Load FAQ data
with open("faqs.json", "r", encoding="utf-8") as file:
    faqs = json.load(file)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    question = data.get("question", "")

    # Prepare FAQ information for the AI
    faq_context = "\n".join(
        [
            f"Question: {faq['question']}\nAnswer: {faq['answer']}"
            for faq in faqs
        ]
    )

    # Instructions for the local AI
    prompt = f"""
You are an AI FAQ Assistant.

Answer the user's question using ONLY the FAQ information provided below.

FAQ INFORMATION:
{faq_context}

USER QUESTION:
{question}

Rules:
1. If the answer is available in the FAQ information, answer clearly and briefly.
2. You can understand differently worded questions.
3. Do not invent information.
4. If the answer is not available in the FAQ information, say:
"Sorry, I couldn't find that information in the available FAQs."
5. Keep the answer simple and easy to understand.
"""

    try:
        # Send the question to the local Ollama AI
        response = ollama.chat(
            model="llama3.2:3b",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        answer = response["message"]["content"]

    except Exception as e:
        print("AI ERROR:", e)
        answer = f"AI Error: {e}"

    return jsonify({
        "answer": answer
    })


if __name__ == "__main__":
    app.run(debug=True)